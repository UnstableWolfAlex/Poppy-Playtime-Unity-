using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace PPU.Editor
{
    /// <summary>
    /// Headless WebGL build entry point used by the GitHub Actions workflow
    /// (game-ci/unity-builder, buildMethod: PPU.Editor.PPUWebGLBuild.Build).
    ///
    /// - Builds every enabled scene from Editor Build Settings
    ///   (falls back to "all scenes in the project" if the list is empty)
    /// - Forces Gzip compression (works everywhere with the fetch patch
    ///   baked into the PoppyTheme template)
    /// - Uses the custom "PoppyTheme" WebGL template (dark loading screen)
    /// - Output goes to &lt;project&gt;/build/webgl
    /// </summary>
    public static class PPUWebGLBuild
    {
        public static void Build()
        {
            var projectRoot = Directory.GetParent(Application.dataPath).FullName;
            var outDir = Path.Combine(projectRoot, "build", "webgl");

            Debug.Log("[PPU] WebGL build starting. Output: " + outDir);

            // ---- WebGL player settings ------------------------------------
            PlayerSettings.WebGL.compressionFormat = WebGLCompressionFormat.Gzip;
            PlayerSettings.WebGL.decompressionFallback = false; // our template handles gzip in JS

            try
            {
                PlayerSettings.WebGL.template = "PROJECT:PoppyTheme";
                Debug.Log("[PPU] WebGL template set to PROJECT:PoppyTheme");
            }
            catch (Exception e)
            {
                Debug.LogWarning("[PPU] Could not select PoppyTheme template, falling back to default. " + e.Message);
            }

            // ---- Scenes ----------------------------------------------------
            var scenes = EditorBuildSettings.scenes
                .Where(s => s.enabled)
                .Select(s => s.path)
                .ToArray();

            if (scenes == null || scenes.Length == 0)
            {
                Debug.LogWarning("[PPU] Editor Build Settings has no enabled scenes - falling back to every scene in the project.");
                scenes = AssetDatabase.FindAssets("t:Scene")
                    .Select(guid => AssetDatabase.GUIDToAssetPath(guid))
                    .Where(p => !string.IsNullOrEmpty(p))
                    .Distinct()
                    .OrderBy(p => p) // deterministic order; SampleScene sorts before others alphabetically
                    .ToArray();
            }

            if (scenes.Length == 0)
            {
                Debug.LogError("[PPU] No scenes found in this project - cannot build.");
                EditorApplication.Exit(1);
                return;
            }

            Debug.Log("[PPU] Scenes in build: " + string.Join(", ", scenes));

            // ---- Build ------------------------------------------------------
            var options = new BuildPlayerOptions
            {
                scenes = scenes,
                locationPathName = outDir,
                target = BuildTarget.WebGL,
                options = BuildOptions.None
            };

            BuildReport report;
            try
            {
                report = BuildPipeline.BuildPlayer(options);
            }
            catch (Exception e)
            {
                Debug.LogError("[PPU] BuildPlayer threw: " + e);
                EditorApplication.Exit(1);
                return;
            }

            var summary = report.summary;
            Debug.Log($"[PPU] Build result: {summary.result} | size: {summary.totalSize / (1024 * 1024)} MB | warnings: {summary.totalWarnings} | errors: {summary.totalErrors}");

            if (summary.result != BuildResult.Succeeded)
            {
                EditorApplication.Exit(1);
                return;
            }

            Debug.Log("[PPU] WebGL build finished successfully.");
            EditorApplication.Exit(0);
        }
    }
}
